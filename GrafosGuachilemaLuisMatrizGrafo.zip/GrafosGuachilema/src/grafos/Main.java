package grafos;
public class Main {
    public static void main(String[] args) {    	
        GrafoMatriz grafo = new GrafoMatriz();
        Menu mostrarMenu=new Menu();
        mostrarMenu.menu(grafo);
    }
}
